const openaiService = require('../services/openai');
const logger = require('../utils/logger');
const config = require('../config');

class ImageHandler {
    /**
     * Обработка изображений от пользователей
     */
    async handleImage(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        try {
            // Показываем что бот анализирует
            await bot.sendChatAction(chatId, 'typing');
            
            await bot.sendMessage(chatId, 
                '🔍 Анализирую изображение... Это может занять несколько секунд.',
                { parse_mode: 'Markdown' }
            );

            // Получаем самое большое изображение
            const photo = msg.photo[msg.photo.length - 1];
            
            // Проверяем размер файла
            if (photo.file_size > config.MAX_IMAGE_SIZE) {
                await bot.sendMessage(chatId, 
                    '❌ Изображение слишком большое. Максимальный размер: 20MB.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }

            // Получаем файл
            const fileData = await bot.getFile(photo.file_id);
            const imageBuffer = await this.downloadFile(bot, fileData.file_path);
            
            // Конвертируем в base64
            const base64Image = imageBuffer.toString('base64');

            logger.info(`Processing image from user ${userId}, file_id: ${photo.file_id}`);

            // Анализируем изображение с помощью OpenAI
            const analysis = await openaiService.analyzeImage(base64Image);

            // Отправляем результат анализа
            const maxLength = 4096;
            if (analysis.length > maxLength) {
                const chunks = this.splitMessage(analysis, maxLength);
                for (let i = 0; i < chunks.length; i++) {
                    await bot.sendMessage(chatId, chunks[i], { parse_mode: 'Markdown' });
                    
                    if (i < chunks.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
            } else {
                await bot.sendMessage(chatId, analysis, { parse_mode: 'Markdown' });
            }

            // Добавляем кнопки для дополнительных действий
            const keyboard = {
                inline_keyboard: [
                    [
                        { text: '💻 Создать код', callback_data: `create_code_${userId}` },
                        { text: '🔧 Исправить ошибки', callback_data: `fix_errors_${userId}` }
                    ],
                    [
                        { text: '📚 Объяснить подробнее', callback_data: `explain_detail_${userId}` },
                        { text: '⚡ Оптимизировать', callback_data: `optimize_${userId}` }
                    ],
                    [
                        { text: '🚀 Задеплоить код', callback_data: `deploy_image_${userId}` },
                        { text: '📦 Создать проект', callback_data: `create_project_image_${userId}` }
                    ]
                ]
            };

            await bot.sendMessage(chatId, 
                '🤖 Что еще нужно сделать с этим кодом?', 
                { reply_markup: keyboard }
            );

        } catch (error) {
            logger.error(`Error handling image from user ${userId}:`, error);
            
            let errorMessage = '❌ Не удалось проанализировать изображение.';
            
            if (error.message.includes('rate limit')) {
                errorMessage = '⏰ Превышен лимит запросов к ИИ. Попробуйте через несколько минут.';
            } else if (error.message.includes('content policy')) {
                errorMessage = '⚠️ Изображение содержит запрещенный контент.';
            } else if (error.message.includes('file size')) {
                errorMessage = '📏 Файл слишком большой или поврежден.';
            }

            await bot.sendMessage(chatId, 
                errorMessage + '\n\nПопробуйте:\n' +
                '• Использовать изображение меньшего размера\n' +
                '• Убедиться что на изображении есть код\n' +
                '• Повторить попытку через минуту',
                { parse_mode: 'Markdown' }
            );
        }
    }

    /**
     * Загрузка файла от Telegram
     */
    async downloadFile(bot, filePath) {
        const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${filePath}`;
        
        const https = require('https');
        
        return new Promise((resolve, reject) => {
            https.get(fileUrl, (response) => {
                if (response.statusCode !== 200) {
                    reject(new Error(`Failed to download file: ${response.statusCode}`));
                    return;
                }

                const chunks = [];
                response.on('data', (chunk) => chunks.push(chunk));
                response.on('end', () => resolve(Buffer.concat(chunks)));
                response.on('error', reject);
            }).on('error', reject);
        });
    }

    /**
     * Разбиение длинных сообщений
     */
    splitMessage(text, maxLength) {
        const chunks = [];
        let currentChunk = '';

        const lines = text.split('\n');
        
        for (const line of lines) {
            if (currentChunk.length + line.length + 1 > maxLength) {
                if (currentChunk) {
                    chunks.push(currentChunk.trim());
                    currentChunk = '';
                }
                
                if (line.length > maxLength) {
                    const subChunks = line.match(new RegExp(`.{1,${maxLength - 10}}`, 'g'));
                    chunks.push(...subChunks);
                } else {
                    currentChunk = line;
                }
            } else {
                currentChunk += (currentChunk ? '\n' : '') + line;
            }
        }
        
        if (currentChunk) {
            chunks.push(currentChunk.trim());
        }
        
        return chunks;
    }

    /**
     * Обработка callback запросов от inline кнопок
     */
    async handleCallbackQuery(bot, callbackQuery) {
        const chatId = callbackQuery.message.chat.id;
        const userId = callbackQuery.from.id;
        const data = callbackQuery.data;

        try {
            await bot.answerCallbackQuery(callbackQuery.id, { text: 'Обрабатываю запрос...' });
            await bot.sendChatAction(chatId, 'typing');

            if (data.startsWith('create_code_')) {
                await bot.sendMessage(chatId, 
                    '💻 Отлично! Опишите какой именно код нужно создать на основе анализа изображения.\n\n' +
                    'Например:\n' +
                    '• "Создай рабочую версию этой функции"\n' +
                    '• "Напиши полный класс с этими методами"\n' +
                    '• "Реализуй этот алгоритм на Python"',
                    { parse_mode: 'Markdown' }
                );
            } else if (data.startsWith('fix_errors_')) {
                await bot.sendMessage(chatId, 
                    '🔧 Найдите и исправьте ошибки в коде с изображения!\n\n' +
                    'Опишите какие проблемы вы заметили или просто напишите "исправь ошибки".',
                    { parse_mode: 'Markdown' }
                );
            } else if (data.startsWith('explain_detail_')) {
                await bot.sendMessage(chatId, 
                    '📚 Что именно нужно объяснить подробнее?\n\n' +
                    '• Как работает алгоритм\n' +
                    '• Что делает каждая функция\n' +
                    '• Объяснить сложные части\n' +
                    '• Рассказать о паттернах проектирования',
                    { parse_mode: 'Markdown' }
                );
            } else if (data.startsWith('optimize_')) {
                await bot.sendMessage(chatId, 
                    '⚡ Оптимизирую код с изображения!\n\n' +
                    'Напишите "оптимизируй код" или укажите конкретные требования к оптимизации.',
                    { parse_mode: 'Markdown' }
                );
            }

        } catch (error) {
            logger.error(`Error handling callback query from user ${userId}:`, error);
            await bot.sendMessage(chatId, '❌ Произошла ошибка. Попробуйте еще раз.');
        }
    }
}

module.exports = new ImageHandler();
