const openaiService = require('../services/openai');
const deploymentService = require('../services/deployment');
const logger = require('../utils/logger');

class MessageHandler {
    constructor() {
        this.userSessions = new Map(); // Хранение сессий пользователей
        this.rateLimiter = new Map(); // Простое ограничение частоты запросов
    }

    /**
     * Проверка ограничений частоты запросов
     */
    checkRateLimit(userId) {
        const now = Date.now();
        const userRequests = this.rateLimiter.get(userId) || [];
        
        // Удаляем старые запросы (старше 1 минуты)
        const recentRequests = userRequests.filter(time => now - time < 60000);
        
        if (recentRequests.length >= 10) {
            return false;
        }
        
        recentRequests.push(now);
        this.rateLimiter.set(userId, recentRequests);
        return true;
    }

    /**
     * Определение типа запроса пользователя
     */
    detectRequestType(text) {
        const lowerText = text.toLowerCase();
        
        // Ключевые слова для генерации кода
        const codeKeywords = ['создай', 'напиши', 'сделай', 'код', 'программа', 'скрипт', 'функция', 'класс', 'api', 'бот', 'приложение'];
        
        // Ключевые слова для объяснений
        const explainKeywords = ['что такое', 'как работает', 'объясни', 'расскажи', 'покажи', 'пример', 'как сделать', 'как использовать'];
        
        // Ключевые слова для улучшения кода
        const improveKeywords = ['улучши', 'исправь', 'оптимизируй', 'переделай', 'рефактор'];
        
        if (codeKeywords.some(keyword => lowerText.includes(keyword))) {
            return 'generate_code';
        }
        
        if (explainKeywords.some(keyword => lowerText.includes(keyword))) {
            return 'explain';
        }
        
        if (improveKeywords.some(keyword => lowerText.includes(keyword))) {
            return 'improve_code';
        }
        
        // Если содержит код (проверяем на наличие программистских символов)
        if (this.containsCode(text)) {
            return 'improve_code';
        }
        
        // По умолчанию - генерация кода
        return 'generate_code';
    }

    /**
     * Проверка содержит ли текст код
     */
    containsCode(text) {
        const codeIndicators = [
            'function', 'def ', 'class ', 'import ', 'const ', 'let ', 'var ',
            '{', '}', '=>', 'console.log', 'print(', 'return ', 'if __name__',
            'public class', 'private ', 'public ', '#include', 'using namespace'
        ];
        
        return codeIndicators.some(indicator => text.includes(indicator));
    }

    /**
     * Определение языка программирования из текста
     */
    detectLanguage(text) {
        const lowerText = text.toLowerCase();
        
        const languageKeywords = {
            'python': ['python', 'питон', 'django', 'flask', 'pandas', 'numpy'],
            'javascript': ['javascript', 'js', 'node', 'nodejs', 'react', 'vue', 'angular'],
            'java': ['java', 'джава', 'spring', 'hibernate'],
            'cpp': ['c++', 'cpp', 'с++'],
            'csharp': ['c#', 'с#', '.net', 'dotnet'],
            'go': ['golang', 'go ', ' go'],
            'rust': ['rust', 'раст'],
            'php': ['php', 'пхп', 'laravel'],
            'sql': ['sql', 'mysql', 'postgresql', 'база данных'],
            'html': ['html', 'веб-страница', 'сайт'],
            'css': ['css', 'стили'],
            'typescript': ['typescript', 'ts']
        };
        
        for (const [language, keywords] of Object.entries(languageKeywords)) {
            if (keywords.some(keyword => lowerText.includes(keyword))) {
                return language;
            }
        }
        
        return null;
    }

    /**
     * Основной обработчик текстовых сообщений
     */
    async handleTextMessage(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text;

        try {
            // Проверка ограничений
            if (!this.checkRateLimit(userId)) {
                await bot.sendMessage(chatId, 
                    '⏰ Превышен лимит запросов. Подождите минуту перед следующим запросом.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }

            // Показываем что бот печатает
            await bot.sendChatAction(chatId, 'typing');

            // Определяем тип запроса
            const requestType = this.detectRequestType(text);
            const language = this.detectLanguage(text);

            logger.info(`Processing ${requestType} request from user ${userId}: ${text.substring(0, 100)}...`);

            let response;

            switch (requestType) {
                case 'generate_code':
                    response = await openaiService.generateCode(text, language);
                    break;
                
                case 'explain':
                    response = await openaiService.explainConcept(text);
                    break;
                
                case 'improve_code':
                    response = await openaiService.improveCode(text);
                    break;
                
                default:
                    response = await openaiService.generateCode(text, language);
            }

            // Разбиваем длинные сообщения
            const maxLength = 4096;
            if (response.length > maxLength) {
                const chunks = this.splitMessage(response, maxLength);
                for (let i = 0; i < chunks.length; i++) {
                    await bot.sendMessage(chatId, chunks[i], { parse_mode: 'Markdown' });
                    
                    // Небольшая задержка между частями
                    if (i < chunks.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
            } else {
                await bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
            }

            // Отправляем дополнительные опции
            const keyboard = {
                inline_keyboard: [
                    [
                        { text: '🔄 Другой вариант', callback_data: `regenerate_${userId}` },
                        { text: '❓ Объяснить код', callback_data: `explain_${userId}` }
                    ],
                    [
                        { text: '⚡ Улучшить код', callback_data: `improve_${userId}` },
                        { text: '💡 Больше примеров', callback_data: `examples_${userId}` }
                    ],
                    [
                        { text: '🚀 Задеплоить код', callback_data: `deploy_${userId}` },
                        { text: '📦 Создать проект', callback_data: `create_project_${userId}` }
                    ]
                ]
            };

            await bot.sendMessage(chatId, 
                '🤖 Нужна дополнительная помощь?', 
                { reply_markup: keyboard }
            );

            // Сохраняем контекст сессии
            this.userSessions.set(userId, {
                lastQuery: text,
                lastResponse: response,
                lastCode: this.extractCodeFromResponse(response),
                requestType: requestType,
                language: language,
                timestamp: Date.now()
            });

        } catch (error) {
            logger.error(`Error handling message from user ${userId}:`, error);
            
            await bot.sendMessage(chatId, 
                '❌ Произошла ошибка при обработке запроса. Попробуйте еще раз или обратитесь к администратору.\n\n' +
                `Детали ошибки: ${error.message}`,
                { parse_mode: 'Markdown' }
            );
        }
    }

    /**
     * Разбиение длинных сообщений на части
     */
    splitMessage(text, maxLength) {
        const chunks = [];
        let currentChunk = '';

        const lines = text.split('\n');
        
        for (const line of lines) {
            if (currentChunk.length + line.length + 1 > maxLength) {
                if (currentChunk) {
                    chunks.push(currentChunk.trim());
                    currentChunk = '';
                }
                
                // Если одна строка длиннее лимита
                if (line.length > maxLength) {
                    const subChunks = line.match(new RegExp(`.{1,${maxLength - 10}}`, 'g'));
                    chunks.push(...subChunks);
                } else {
                    currentChunk = line;
                }
            } else {
                currentChunk += (currentChunk ? '\n' : '') + line;
            }
        }
        
        if (currentChunk) {
            chunks.push(currentChunk.trim());
        }
        
        return chunks;
    }

    /**
     * Извлечение кода из ответа ИИ
     */
    extractCodeFromResponse(response) {
        // Ищем блоки кода в markdown формате
        const codeBlockRegex = /```[\s\S]*?\n([\s\S]*?)\n```/g;
        const codeBlocks = [];
        let match;

        while ((match = codeBlockRegex.exec(response)) !== null) {
            codeBlocks.push(match[1].trim());
        }

        return codeBlocks.length > 0 ? codeBlocks.join('\n\n') : null;
    }

    /**
     * Обработка callback запросов
     */
    async handleCallbackQuery(bot, callbackQuery) {
        const chatId = callbackQuery.message.chat.id;
        const userId = callbackQuery.from.id;
        const data = callbackQuery.data;

        try {
            await bot.answerCallbackQuery(callbackQuery.id, { text: 'Обрабатываю...' });

            const session = this.userSessions.get(userId);

            if (data.startsWith('deploy_')) {
                await this.handleDeployRequest(bot, chatId, userId, session);
            } else if (data.startsWith('create_project_')) {
                await this.handleCreateProjectRequest(bot, chatId, userId, session);
            } else if (data.startsWith('deploy_to_')) {
                const platform = data.split('deploy_to_')[1];
                await this.handlePlatformDeploy(bot, chatId, userId, session, platform);
            } else if (data.startsWith('regenerate_')) {
                await this.handleRegenerateRequest(bot, chatId, userId, session);
            } else if (data.startsWith('explain_')) {
                await this.handleExplainRequest(bot, chatId, userId, session);
            } else if (data.startsWith('improve_')) {
                await this.handleImproveRequest(bot, chatId, userId, session);
            }

        } catch (error) {
            logger.error(`Error handling callback query from user ${userId}:`, error);
            await bot.sendMessage(chatId, '❌ Произошла ошибка. Попробуйте еще раз.');
        }
    }

    /**
     * Обработка запроса на деплой
     */
    async handleDeployRequest(bot, chatId, userId, session) {
        if (!session || !session.lastCode) {
            await bot.sendMessage(chatId, '❌ Сначала создайте код, который нужно задеплоить.');
            return;
        }

        const platforms = deploymentService.getAvailablePlatforms();
        const platformButtons = platforms.map(platform => ([
            {
                text: `${platform.free ? '🆓' : '💰'} ${platform.name}`,
                callback_data: `deploy_to_${platform.id}`
            }
        ]));

        const keyboard = { inline_keyboard: platformButtons };

        await bot.sendMessage(chatId, 
            '🚀 **Выберите платформу для деплоя:**\n\n' +
            platforms.map(p => 
                `${p.free ? '🆓' : '💰'} **${p.name}** - ${p.description}\n` +
                `24/7: ${p.supports247 ? '✅' : '❌'}`
            ).join('\n\n'),
            { 
                parse_mode: 'Markdown',
                reply_markup: keyboard 
            }
        );
    }

    /**
     * Обработка запроса на создание проекта
     */
    async handleCreateProjectRequest(bot, chatId, userId, session) {
        if (!session || !session.lastCode) {
            await bot.sendMessage(chatId, '❌ Сначала создайте код для проекта.');
            return;
        }

        await bot.sendMessage(chatId, 
            '📦 **Создание проекта...**\n\n' +
            'Введите название проекта (на английском, без пробелов):\n' +
            'Например: `my-awesome-bot` или `weather-app`',
            { parse_mode: 'Markdown' }
        );

        // Устанавливаем статус ожидания названия проекта
        session.waitingForProjectName = true;
        this.userSessions.set(userId, session);
    }

    /**
     * Обработка деплоя на конкретную платформу
     */
    async handlePlatformDeploy(bot, chatId, userId, session, platform) {
        if (!session || !session.lastCode) {
            await bot.sendMessage(chatId, '❌ Код не найден. Создайте код сначала.');
            return;
        }

        await bot.sendChatAction(chatId, 'typing');

        try {
            const projectName = `ai-generated-${Date.now()}`;
            const project = await deploymentService.createProjectStructure(
                session.lastCode,
                session.language,
                projectName
            );

            const instructions = deploymentService.generateDeploymentInstructions(
                platform,
                projectName,
                session.language || 'javascript'
            );

            // Отправляем файлы как документы
            const files = Object.entries(project.structure.files);
            
            await bot.sendMessage(chatId, 
                `📦 **Проект "${projectName}" готов к деплою!**\n\n` +
                `Всего файлов: ${files.length}\n` +
                `Платформа: ${platform}\n\n` +
                `⬇️ Сейчас отправлю все файлы проекта...`,
                { parse_mode: 'Markdown' }
            );

            // Отправляем файлы по очереди
            for (const [fileName, content] of files) {
                const buffer = Buffer.from(content, 'utf8');
                
                await bot.sendDocument(chatId, buffer, {}, {
                    filename: fileName,
                    contentType: 'text/plain'
                });
                
                // Небольшая задержка между файлами
                await new Promise(resolve => setTimeout(resolve, 500));
            }

            // Отправляем инструкции
            await bot.sendMessage(chatId, instructions, { parse_mode: 'Markdown' });

        } catch (error) {
            logger.error(`Error creating deployment for user ${userId}:`, error);
            await bot.sendMessage(chatId, 
                '❌ Ошибка создания проекта для деплоя.\n' +
                `Детали: ${error.message}`
            );
        }
    }

    /**
     * Обработка запроса на регенерацию
     */
    async handleRegenerateRequest(bot, chatId, userId, session) {
        if (!session || !session.lastQuery) {
            await bot.sendMessage(chatId, '❌ Нет предыдущего запроса для повторной генерации.');
            return;
        }

        await bot.sendChatAction(chatId, 'typing');
        await bot.sendMessage(chatId, '🔄 Создаю другой вариант...');

        const response = await openaiService.generateCode(
            session.lastQuery + '\n\nСоздай другой вариант с отличающимся подходом.',
            session.language
        );

        const maxLength = 4096;
        if (response.length > maxLength) {
            const chunks = this.splitMessage(response, maxLength);
            for (let i = 0; i < chunks.length; i++) {
                await bot.sendMessage(chatId, chunks[i], { parse_mode: 'Markdown' });
                if (i < chunks.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
        } else {
            await bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
        }

        // Обновляем сессию
        session.lastResponse = response;
        session.lastCode = this.extractCodeFromResponse(response);
        this.userSessions.set(userId, session);
    }

    /**
     * Обработка запроса на объяснение
     */
    async handleExplainRequest(bot, chatId, userId, session) {
        if (!session || !session.lastCode) {
            await bot.sendMessage(chatId, '❌ Нет кода для объяснения.');
            return;
        }

        await bot.sendChatAction(chatId, 'typing');
        await bot.sendMessage(chatId, '📚 Объясняю код подробно...');

        const explanation = await openaiService.explainConcept(
            'Объясни подробно что делает этот код и как он работает:\n\n' + session.lastCode
        );

        const maxLength = 4096;
        if (explanation.length > maxLength) {
            const chunks = this.splitMessage(explanation, maxLength);
            for (let i = 0; i < chunks.length; i++) {
                await bot.sendMessage(chatId, chunks[i], { parse_mode: 'Markdown' });
                if (i < chunks.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
        } else {
            await bot.sendMessage(chatId, explanation, { parse_mode: 'Markdown' });
        }
    }

    /**
     * Обработка запроса на улучшение
     */
    async handleImproveRequest(bot, chatId, userId, session) {
        if (!session || !session.lastCode) {
            await bot.sendMessage(chatId, '❌ Нет кода для улучшения.');
            return;
        }

        await bot.sendChatAction(chatId, 'typing');
        await bot.sendMessage(chatId, '⚡ Улучшаю код...');

        const improved = await openaiService.improveCode(session.lastCode);

        const maxLength = 4096;
        if (improved.length > maxLength) {
            const chunks = this.splitMessage(improved, maxLength);
            for (let i = 0; i < chunks.length; i++) {
                await bot.sendMessage(chatId, chunks[i], { parse_mode: 'Markdown' });
                if (i < chunks.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
        } else {
            await bot.sendMessage(chatId, improved, { parse_mode: 'Markdown' });
        }

        // Обновляем сессию с улучшенным кодом
        session.lastResponse = improved;
        session.lastCode = this.extractCodeFromResponse(improved);
        this.userSessions.set(userId, session);
    }
}

module.exports = new MessageHandler();
