const config = require('../config');

class Logger {
    constructor() {
        this.logLevel = this.getLogLevel(config.LOG_LEVEL);
        this.colors = {
            error: '\x1b[31m',   // Красный
            warn: '\x1b[33m',    // Желтый
            info: '\x1b[36m',    // Циан
            debug: '\x1b[32m',   // Зеленый
            reset: '\x1b[0m'     // Сброс цвета
        };
    }

    getLogLevel(level) {
        const levels = { error: 0, warn: 1, info: 2, debug: 3 };
        return levels[level] || 2;
    }

    formatMessage(level, message, data = null) {
        const timestamp = new Date().toISOString();
        const color = this.colors[level] || '';
        const reset = this.colors.reset;
        
        let logMessage = `${color}[${timestamp}] [${level.toUpperCase()}] ${message}${reset}`;
        
        if (data) {
            if (typeof data === 'object') {
                logMessage += '\n' + JSON.stringify(data, null, 2);
            } else {
                logMessage += ' ' + data;
            }
        }
        
        return logMessage;
    }

    error(message, data = null) {
        if (this.logLevel >= 0) {
            console.error(this.formatMessage('error', message, data));
        }
    }

    warn(message, data = null) {
        if (this.logLevel >= 1) {
            console.warn(this.formatMessage('warn', message, data));
        }
    }

    info(message, data = null) {
        if (this.logLevel >= 2) {
            console.log(this.formatMessage('info', message, data));
        }
    }

    debug(message, data = null) {
        if (this.logLevel >= 3) {
            console.log(this.formatMessage('debug', message, data));
        }
    }

    // Специальные методы для разных типов событий
    userAction(userId, action, details = null) {
        this.info(`User ${userId} performed action: ${action}`, details);
    }

    apiCall(service, method, duration = null) {
        const message = `API Call: ${service}.${method}`;
        const data = duration ? { duration: `${duration}ms` } : null;
        this.debug(message, data);
    }

    botEvent(event, details = null) {
        this.info(`Bot Event: ${event}`, details);
    }

    performance(operation, duration, additionalData = null) {
        this.debug(`Performance: ${operation} took ${duration}ms`, additionalData);
    }

    security(event, userId, details = null) {
        this.warn(`Security Event: ${event} (User: ${userId})`, details);
    }
}

module.exports = new Logger();
