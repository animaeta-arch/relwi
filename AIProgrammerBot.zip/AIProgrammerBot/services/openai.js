const OpenAI = require('openai');
const config = require('../config');
const logger = require('../utils/logger');

class OpenAIService {
    constructor() {
        this.client = new OpenAI({
            apiKey: config.OPENAI_API_KEY
        });
    }

    /**
     * Генерация кода на основе текстового запроса
     */
    async generateCode(prompt, language = null) {
        try {
            const systemPrompt = `Ты эксперт программист, который создает высококачественный код на всех языках программирования. 
            
Твои возможности:
- Знаешь все современные языки программирования
- Создаешь полнофункциональный код без ограничений
- Пишешь код для любых задач: от простых скриптов до сложных приложений
- Умеешь создавать телеграм ботов, веб-приложения, API, десктоп приложения
- Знаешь лучшие практики и современные технологии

Правила генерации кода:
1. Всегда создавай полный, рабочий код
2. Добавляй подробные комментарии на русском языке
3. Используй современные подходы и библиотеки
4. Включай обработку ошибок
5. Делай код максимально функциональным
6. При создании ботов - всегда добавляй все необходимые команды

${language ? `Язык программирования: ${language}` : 'Выбери наиболее подходящий язык программирования для задачи.'}

Отвечай в следующем формате:
**Язык:** [название языка]
**Описание:** [краткое описание решения]
**Код:**
\`\`\`[язык]
[полный код]
\`\`\`
**Объяснение:** [как использовать код]`;

            const response = await this.client.chat.completions.create({
                model: config.OPENAI_MODEL, // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: prompt }
                ],
                max_tokens: config.OPENAI_MAX_TOKENS,
                temperature: config.OPENAI_TEMPERATURE
            });

            logger.info(`Code generated for prompt: ${prompt.substring(0, 100)}...`);
            return response.choices[0].message.content;

        } catch (error) {
            logger.error('Error generating code:', error);
            throw new Error(`Ошибка генерации кода: ${error.message}`);
        }
    }

    /**
     * Анализ изображения с кодом
     */
    async analyzeImage(base64Image) {
        try {
            const response = await this.client.chat.completions.create({
                model: config.OPENAI_MODEL, // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
                messages: [
                    {
                        role: "user",
                        content: [
                            {
                                type: "text",
                                text: `Проанализируй это изображение и опиши найденный на нем код. 
                                
Если на изображении есть код:
1. Определи язык программирования
2. Опиши что делает код
3. Найди возможные ошибки или улучшения
4. Предложи исправленную версию кода
5. Объясни как код работает

Если на изображении нет кода:
1. Опиши что изображено
2. Если это диаграмма или схема - объясни как можно реализовать это в коде

Отвечай на русском языке подробно и структурированно.`
                            },
                            {
                                type: "image_url",
                                image_url: {
                                    url: `data:image/jpeg;base64,${base64Image}`
                                }
                            }
                        ],
                    },
                ],
                max_tokens: 2000,
            });

            logger.info('Image analyzed successfully');
            return response.choices[0].message.content;

        } catch (error) {
            logger.error('Error analyzing image:', error);
            throw new Error(`Ошибка анализа изображения: ${error.message}`);
        }
    }

    /**
     * Объяснение кода или концепций программирования
     */
    async explainConcept(question) {
        try {
            const systemPrompt = `Ты опытный преподаватель программирования и ментор. Твоя задача - объяснять сложные концепции программирования простым и понятным языком.

Принципы объяснения:
1. Начинай с простых примеров
2. Используй аналогии из реальной жизни
3. Приводи практические примеры кода
4. Объясняй пошагово
5. Отвечай на русском языке
6. Будь терпеливым и подробным

Форматируй ответ структурированно с заголовками и примерами кода.`;

            const response = await this.client.chat.completions.create({
                model: config.OPENAI_MODEL, // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: question }
                ],
                max_tokens: config.OPENAI_MAX_TOKENS,
                temperature: 0.8
            });

            logger.info(`Concept explained: ${question.substring(0, 100)}...`);
            return response.choices[0].message.content;

        } catch (error) {
            logger.error('Error explaining concept:', error);
            throw new Error(`Ошибка объяснения: ${error.message}`);
        }
    }

    /**
     * Улучшение существующего кода
     */
    async improveCode(code, improvementRequest = null) {
        try {
            const systemPrompt = `Ты эксперт по рефакторингу и оптимизации кода. Анализируй предоставленный код и улучшай его.

Что нужно проверить и улучшить:
1. Читаемость и структуру кода
2. Производительность
3. Безопасность
4. Обработку ошибок
5. Следование лучшим практикам
6. Добавление комментариев

Отвечай в формате:
**Анализ текущего кода:**
[описание проблем и недостатков]

**Улучшенный код:**
\`\`\`[язык]
[улучшенный код]
\`\`\`

**Объяснение улучшений:**
[что было изменено и почему]`;

            const userPrompt = improvementRequest 
                ? `Улучши этот код с учетом требования: ${improvementRequest}\n\nКод:\n${code}`
                : `Улучши этот код:\n${code}`;

            const response = await this.client.chat.completions.create({
                model: config.OPENAI_MODEL, // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: userPrompt }
                ],
                max_tokens: config.OPENAI_MAX_TOKENS,
                temperature: 0.6
            });

            logger.info('Code improvement completed');
            return response.choices[0].message.content;

        } catch (error) {
            logger.error('Error improving code:', error);
            throw new Error(`Ошибка улучшения кода: ${error.message}`);
        }
    }
}

module.exports = new OpenAIService();
