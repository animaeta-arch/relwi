const axios = require('axios');
const logger = require('../utils/logger');
const fs = require('fs').promises;
const path = require('path');

class DeploymentService {
    constructor() {
        this.supportedPlatforms = {
            'replit': {
                name: 'Replit',
                description: 'Быстрый деплой для тестирования и разработки',
                free: true,
                supports247: true
            },
            'vercel': {
                name: 'Vercel', 
                description: 'Идеально для фронтенда и Next.js приложений',
                free: true,
                supports247: true
            },
            'netlify': {
                name: 'Netlify',
                description: 'Отлично для статических сайтов и JAMstack',
                free: true,
                supports247: true
            },
            'railway': {
                name: 'Railway',
                description: 'Простой деплой для любых приложений',
                free: true,
                supports247: true
            },
            'render': {
                name: 'Render',
                description: 'Бесплатный хостинг для веб-сервисов',
                free: true,
                supports247: false // бесплатный план засыпает
            },
            'heroku': {
                name: 'Heroku',
                description: 'Классический PaaS для веб-приложений',
                free: false,
                supports247: true
            }
        };
    }

    /**
     * Получение списка доступных платформ для деплоя
     */
    getAvailablePlatforms() {
        return Object.entries(this.supportedPlatforms).map(([key, platform]) => ({
            id: key,
            ...platform
        }));
    }

    /**
     * Создание структуры проекта для деплоя
     */
    async createProjectStructure(code, language, projectName) {
        const tempDir = `/tmp/deploy_${Date.now()}`;
        
        try {
            await fs.mkdir(tempDir, { recursive: true });
            
            const projectStructure = this.generateProjectStructure(code, language, projectName);
            
            // Создаем файлы проекта
            for (const [fileName, content] of Object.entries(projectStructure.files)) {
                const filePath = path.join(tempDir, fileName);
                await fs.mkdir(path.dirname(filePath), { recursive: true });
                await fs.writeFile(filePath, content, 'utf8');
            }
            
            logger.info(`Project structure created at ${tempDir}`);
            return {
                path: tempDir,
                structure: projectStructure,
                deploymentInstructions: projectStructure.deploymentInstructions
            };
            
        } catch (error) {
            logger.error('Error creating project structure:', error);
            throw new Error(`Ошибка создания структуры проекта: ${error.message}`);
        }
    }

    /**
     * Генерация структуры проекта в зависимости от языка
     */
    generateProjectStructure(code, language, projectName) {
        const projectSlug = projectName.toLowerCase().replace(/[^a-z0-9]/g, '-');
        
        switch (language?.toLowerCase()) {
            case 'javascript':
            case 'nodejs':
                return this.generateNodeJSProject(code, projectSlug);
            
            case 'python':
                return this.generatePythonProject(code, projectSlug);
                
            case 'html':
            case 'css':
            case 'web':
                return this.generateWebProject(code, projectSlug);
                
            case 'go':
                return this.generateGoProject(code, projectSlug);
                
            default:
                return this.generateGenericProject(code, projectSlug, language);
        }
    }

    /**
     * Генерация Node.js проекта
     */
    generateNodeJSProject(code, projectName) {
        const packageJson = {
            "name": projectName,
            "version": "1.0.0",
            "description": "Автоматически созданное приложение с помощью ИИ бота",
            "main": "index.js",
            "scripts": {
                "start": "node index.js",
                "dev": "node index.js"
            },
            "dependencies": this.detectNodeDependencies(code),
            "engines": {
                "node": ">=16.0.0"
            }
        };

        return {
            files: {
                'package.json': JSON.stringify(packageJson, null, 2),
                'index.js': code,
                '.env.example': this.generateEnvExample(code),
                'README.md': this.generateReadme(projectName, 'Node.js', code),
                '.replit': this.generateReplitConfig('nodejs'),
                'replit.nix': this.generateNixConfig('nodejs')
            },
            deploymentInstructions: {
                replit: "Файлы готовы к деплою на Replit. Просто создайте новый Repl и загрузите файлы.",
                vercel: "Установите Vercel CLI: npm i -g vercel, затем выполните: vercel --prod",
                railway: "Подключите GitHub репозиторий к Railway или используйте Railway CLI",
                render: "Создайте Web Service на Render.com и подключите репозиторий"
            }
        };
    }

    /**
     * Генерация Python проекта
     */
    generatePythonProject(code, projectName) {
        const requirements = this.detectPythonDependencies(code);
        
        return {
            files: {
                'main.py': code,
                'requirements.txt': requirements.join('\n'),
                '.env.example': this.generateEnvExample(code),
                'README.md': this.generateReadme(projectName, 'Python', code),
                '.replit': this.generateReplitConfig('python'),
                'replit.nix': this.generateNixConfig('python'),
                'runtime.txt': 'python-3.11.0'
            },
            deploymentInstructions: {
                replit: "Файлы готовы к деплою на Replit. Создайте Python Repl и загрузите файлы.",
                railway: "Подключите GitHub репозиторий к Railway",
                render: "Создайте Web Service на Render.com с Python окружением",
                heroku: "Используйте Heroku CLI: heroku create && git push heroku main"
            }
        };
    }

    /**
     * Генерация веб-проекта (HTML/CSS/JS)
     */
    generateWebProject(code, projectName) {
        const isFullHtml = code.includes('<!DOCTYPE html>') || code.includes('<html>');
        
        const files = {};
        
        if (isFullHtml) {
            files['index.html'] = code;
        } else {
            files['index.html'] = `<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    ${code}
    <script src="script.js"></script>
</body>
</html>`;
            files['styles.css'] = '/* Добавьте ваши стили здесь */';
            files['script.js'] = '// Добавьте ваш JavaScript код здесь';
        }

        files['README.md'] = this.generateReadme(projectName, 'Web', code);
        files['.replit'] = this.generateReplitConfig('html');
        files['replit.nix'] = this.generateNixConfig('html');

        return {
            files,
            deploymentInstructions: {
                replit: "Создайте HTML/CSS/JS Repl и загрузите файлы",
                netlify: "Перетащите папку проекта на netlify.com или подключите Git репозиторий",
                vercel: "Используйте Vercel CLI или подключите GitHub репозиторий",
                github_pages: "Загрузите в GitHub репозиторий и включите GitHub Pages"
            }
        };
    }

    /**
     * Генерация Go проекта
     */
    generateGoProject(code, projectName) {
        return {
            files: {
                'main.go': code,
                'go.mod': `module ${projectName}\n\ngo 1.21`,
                'README.md': this.generateReadme(projectName, 'Go', code),
                '.replit': this.generateReplitConfig('go'),
                'replit.nix': this.generateNixConfig('go')
            },
            deploymentInstructions: {
                replit: "Создайте Go Repl и загрузите файлы",
                railway: "Подключите GitHub репозиторий к Railway",
                render: "Создайте Web Service на Render.com с Go окружением"
            }
        };
    }

    /**
     * Генерация универсального проекта
     */
    generateGenericProject(code, projectName, language) {
        const extension = this.getFileExtension(language);
        
        return {
            files: {
                [`main.${extension}`]: code,
                'README.md': this.generateReadme(projectName, language || 'Generic', code),
                '.replit': this.generateReplitConfig(language?.toLowerCase() || 'bash'),
                'replit.nix': this.generateNixConfig(language?.toLowerCase() || 'bash')
            },
            deploymentInstructions: {
                replit: `Создайте ${language || 'Generic'} Repl и загрузите файлы`
            }
        };
    }

    /**
     * Определение зависимостей Node.js из кода
     */
    detectNodeDependencies(code) {
        const dependencies = {
            "express": "^4.18.2"
        };

        const patterns = {
            'express': /require\(['"]express['"]\)|import.*from ['"]express['"]/,
            'cors': /require\(['"]cors['"]\)|import.*from ['"]cors['"]/,
            'axios': /require\(['"]axios['"]\)|import.*from ['"]axios['"]/,
            'dotenv': /require\(['"]dotenv['"]\)|import.*from ['"]dotenv['"]/,
            'mongoose': /require\(['"]mongoose['"]\)|import.*from ['"]mongoose['"]/,
            'socket.io': /require\(['"]socket\.io['"]\)|import.*from ['"]socket\.io['"]/,
            'nodemailer': /require\(['"]nodemailer['"]\)|import.*from ['"]nodemailer['"]/,
            'bcrypt': /require\(['"]bcrypt['"]\)|import.*from ['"]bcrypt['"]/,
            'jsonwebtoken': /require\(['"]jsonwebtoken['"]\)|import.*from ['"]jsonwebtoken['"]/,
            'multer': /require\(['"]multer['"]\)|import.*from ['"]multer['"]/
        };

        for (const [pkg, pattern] of Object.entries(patterns)) {
            if (pattern.test(code)) {
                dependencies[pkg] = "latest";
            }
        }

        return dependencies;
    }

    /**
     * Определение зависимостей Python из кода
     */
    detectPythonDependencies(code) {
        const dependencies = [];

        const patterns = {
            'flask': /from flask import|import flask/,
            'django': /from django import|import django/,
            'fastapi': /from fastapi import|import fastapi/,
            'requests': /import requests/,
            'pandas': /import pandas/,
            'numpy': /import numpy/,
            'matplotlib': /import matplotlib/,
            'sqlalchemy': /from sqlalchemy import|import sqlalchemy/,
            'psycopg2': /import psycopg2/,
            'python-telegram-bot': /from telegram import|import telegram/,
            'openai': /import openai/,
            'beautifulsoup4': /from bs4 import|import bs4/,
            'selenium': /from selenium import|import selenium/
        };

        for (const [pkg, pattern] of Object.entries(patterns)) {
            if (pattern.test(code)) {
                dependencies.push(pkg);
            }
        }

        return dependencies.length > 0 ? dependencies : ['flask'];
    }

    /**
     * Генерация README.md
     */
    generateReadme(projectName, language, code) {
        return `# ${projectName}

Автоматически созданное приложение с помощью ИИ Telegram бота.

## Технологии
- **Язык:** ${language}
- **Создано:** ${new Date().toLocaleDateString('ru-RU')}

## Как запустить

### Локально
\`\`\`bash
# Установите зависимости (если есть package.json или requirements.txt)
${language.toLowerCase() === 'nodejs' ? 'npm install' : ''}
${language.toLowerCase() === 'python' ? 'pip install -r requirements.txt' : ''}

# Запустите приложение
${language.toLowerCase() === 'nodejs' ? 'npm start' : ''}
${language.toLowerCase() === 'python' ? 'python main.py' : ''}
\`\`\`

### На Replit
1. Создайте новый Repl
2. Загрузите все файлы проекта
3. Нажмите кнопку Run

### На других платформах
См. инструкции по деплойменту для конкретной платформы.

## Описание
Этот проект был создан с использованием искусственного интеллекта для демонстрации возможностей автоматической генерации и деплоя кода.

---
*Создано ИИ Telegram ботом для генерации кода*`;
    }

    /**
     * Генерация .replit конфига
     */
    generateReplitConfig(language) {
        const configs = {
            'nodejs': `language = "nodejs"
run = "npm start"
entrypoint = "index.js"

[deployment]
run = ["sh", "-c", "npm start"]`,
            
            'python': `language = "python3"
run = "python main.py"
entrypoint = "main.py"

[deployment]
run = ["python", "main.py"]`,
            
            'html': `language = "html"
run = "python -m http.server 8000"
entrypoint = "index.html"`,
            
            'go': `language = "go"
run = "go run main.go"
entrypoint = "main.go"

[deployment]
run = ["go", "run", "main.go"]`
        };

        return configs[language] || configs['nodejs'];
    }

    /**
     * Генерация replit.nix конфига
     */
    generateNixConfig(language) {
        const configs = {
            'nodejs': `{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.npm
  ];
}`,
            'python': `{ pkgs }: {
  deps = [
    pkgs.python311
    pkgs.python311Packages.pip
  ];
}`,
            'html': `{ pkgs }: {
  deps = [
    pkgs.python3
  ];
}`,
            'go': `{ pkgs }: {
  deps = [
    pkgs.go
  ];
}`
        };

        return configs[language] || configs['nodejs'];
    }

    /**
     * Генерация примера .env файла
     */
    generateEnvExample(code) {
        const envVars = [];

        // Поиск переменных окружения в коде
        const envPattern = /process\.env\.([A-Z_]+)/g;
        let match;
        const foundVars = new Set();

        while ((match = envPattern.exec(code)) !== null) {
            foundVars.add(match[1]);
        }

        for (const varName of foundVars) {
            envVars.push(`${varName}=your_${varName.toLowerCase()}_here`);
        }

        return envVars.length > 0 ? envVars.join('\n') : '# Добавьте ваши переменные окружения здесь';
    }

    /**
     * Получение расширения файла по языку
     */
    getFileExtension(language) {
        const extensions = {
            'python': 'py',
            'javascript': 'js',
            'typescript': 'ts',
            'java': 'java',
            'cpp': 'cpp',
            'go': 'go',
            'rust': 'rs',
            'php': 'php',
            'ruby': 'rb',
            'swift': 'swift',
            'kotlin': 'kt'
        };

        return extensions[language?.toLowerCase()] || 'txt';
    }

    /**
     * Создание архива проекта для деплоя
     */
    async createDeploymentPackage(projectPath) {
        // Здесь можно добавить создание ZIP архива
        // Пока возвращаем путь к папке
        return projectPath;
    }

    /**
     * Генерация инструкций по деплою
     */
    generateDeploymentInstructions(platform, projectName, language) {
        const instructions = {
            replit: `🚀 **Деплой на Replit:**

1. Перейдите на replit.com
2. Нажмите "Create Repl"
3. Выберите "${language}" как язык
4. Назовите проект "${projectName}"
5. Загрузите все созданные файлы
6. Нажмите "Run" для запуска
7. Для 24/7 работы используйте Reserved VM Deployment

✅ **Результат:** Ваше приложение будет доступно по ссылке вида ${projectName}.yourusername.repl.co`,

            vercel: `🚀 **Деплой на Vercel:**

1. Установите Vercel CLI: \`npm i -g vercel\`
2. В папке проекта выполните: \`vercel login\`
3. Затем: \`vercel --prod\`
4. Или загрузите проект через vercel.com

✅ **Результат:** Ваше приложение будет доступно по домену Vercel`,

            netlify: `🚀 **Деплой на Netlify:**

1. Перейдите на netlify.com
2. Перетащите папку проекта в область "Deploy manually"
3. Или подключите GitHub репозиторий

✅ **Результат:** Автоматический деплой с каждым обновлением`,

            railway: `🚀 **Деплой на Railway:**

1. Перейдите на railway.app
2. Подключите GitHub репозиторий
3. Railway автоматически определит настройки

✅ **Результат:** Автоматический деплой с доменом Railway`
        };

        return instructions[platform] || "Инструкции для данной платформы пока не готовы.";
    }
}

module.exports = new DeploymentService();