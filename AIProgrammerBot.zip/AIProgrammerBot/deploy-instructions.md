# 🚀 Инструкции по деплою Telegram ИИ бота

## 🆓 БЕСПЛАТНЫЕ ПЛАТФОРМЫ 24/7

### 1. 🥇 Railway.app (РЕКОМЕНДУЕМЫЙ)
**Преимущества:** $5 бесплатно в месяц, 24/7 работа, автоматический деплой

**Шаги:**
1. Перейдите на https://railway.app
2. Зарегистрируйтесь через GitHub
3. Нажмите "New Project" → "Deploy from GitHub repo"
4. Выберите репозиторий с вашим ботом
5. В разделе "Variables" добавьте:
   - `TELEGRAM_BOT_TOKEN` = ваш токен бота
   - `OPENAI_API_KEY` = ваш ключ OpenAI
6. Railway автоматически определит настройки из `railway.json`
7. Бот запустится автоматически!

**✅ Результат:** Ваш бот работает 24/7 бесплатно!

---

### 2. 🥈 Render.com (Альтернатива)
**Преимущества:** Полностью бесплатно, но засыпает через 15 минут

**Шаги:**
1. Перейдите на https://render.com
2. Зарегистрируйтесь через GitHub
3. Нажмите "New" → "Web Service"
4. Подключите GitHub репозиторий
5. Настройки:
   - **Build Command:** `npm install`
   - **Start Command:** `node bot.js`
6. В разделе "Environment" добавьте переменные:
   - `TELEGRAM_BOT_TOKEN`
   - `OPENAI_API_KEY` 
   - `NODE_ENV=production`
7. Нажмите "Create Web Service"

**🔄 Чтобы не засыпал:** Используйте UptimeRobot для пинга каждые 14 минут

---

### 3. 🥉 Fly.io (Продвинутый)
**Преимущества:** Мощная бесплатная конфигурация

**Шаги:**
1. Установите CLI: `curl -L https://fly.io/install.sh | sh`
2. Зарегистрируйтесь: `flyctl auth signup`
3. В папке проекта: `flyctl launch`
4. Следуйте инструкциям (конфигурация в `fly.toml`)
5. Добавьте секреты:
   ```bash
   flyctl secrets set TELEGRAM_BOT_TOKEN=ваш_токен
   flyctl secrets set OPENAI_API_KEY=ваш_ключ
   ```
6. Деплой: `flyctl deploy`

---

## 📋 Что нужно для деплоя:

1. **GitHub репозиторий** с кодом бота
2. **Telegram Bot Token** (от @BotFather)
3. **OpenAI API Key** (от platform.openai.com)

## 🔧 Подготовка файлов:

Все необходимые файлы уже созданы:
- ✅ `package.json` - зависимости Node.js
- ✅ `railway.json` - конфигурация Railway
- ✅ `render.yaml` - конфигурация Render  
- ✅ `fly.toml` - конфигурация Fly.io
- ✅ `Dockerfile` - для контейнеризации
- ✅ Весь исходный код бота

## 🎯 РЕКОМЕНДАЦИЯ:

**Начните с Railway.app** - это самый простой и надежный бесплатный вариант для 24/7 работы!

---

*Ваш бот будет работать вечно и бесплатно! 🎉*