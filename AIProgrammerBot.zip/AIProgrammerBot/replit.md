# Overview

This is a Telegram AI bot designed for code generation, image analysis, programming education, and **automatic code deployment**. The bot leverages OpenAI's GPT-5 model and Vision API to provide comprehensive coding assistance, including generating code in multiple programming languages, analyzing code screenshots, explaining programming concepts, and automatically deploying created code to various hosting platforms 24/7. The bot supports Russian language interactions and is built with Node.js using a modular architecture.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Application Structure
The application follows a modular Node.js architecture with clear separation of concerns:

- **Entry Point**: `bot.js` serves as the main application file that initializes the Telegram bot and sets up command handlers
- **Configuration Management**: Centralized configuration in `config.js` with environment variable support via dotenv
- **Handler Pattern**: Separate handlers for different types of user interactions (text messages and images)
- **Service Layer**: Dedicated OpenAI service for AI processing and Deployment service for automatic code deployment
- **Utility Layer**: Logging utility for application monitoring and debugging
- **Deployment System**: Automatic project structure generation and deployment to multiple hosting platforms

## Bot Framework Integration
The application uses the `node-telegram-bot-api` library for Telegram Bot API integration, providing:
- Polling-based message reception
- Command routing for `/start`, `/help`, `/code`, and `/analyze` commands
- File download capabilities for image processing
- Message formatting with Markdown support

## AI Processing Architecture
OpenAI integration is handled through a dedicated service class that provides:
- Code generation based on natural language prompts
- Image analysis using Vision API for code screenshot processing
- Intelligent request type detection (code generation, explanation, improvement)
- Context-aware responses with programming language detection

## Deployment Architecture
Automated deployment system supporting multiple hosting platforms:
- **Project Structure Generation**: Automatic creation of deployment-ready project files
- **Platform Support**: Replit, Vercel, Netlify, Railway, Render, and Heroku
- **Language Detection**: Intelligent detection of programming languages and frameworks
- **Dependency Management**: Automatic package.json, requirements.txt, and configuration file generation
- **24/7 Hosting**: Integration with platforms supporting continuous operation
- **File Delivery**: Automatic packaging and delivery of deployment files to users

## Session and Rate Limiting
Simple in-memory session management and rate limiting implementation:
- User session tracking via Map-based storage
- Rate limiting with configurable windows (default: 10 requests per minute)
- Request type classification for optimized AI responses

## Error Handling and Logging
Comprehensive logging system with configurable log levels:
- Color-coded console output for different log levels (error, warn, info, debug)
- Structured logging with timestamps and JSON data support
- Error handling throughout the application flow

## Message Processing Pipeline
Multi-stage message processing approach:
- Rate limit validation
- Request type detection based on keyword analysis
- Context-aware prompt engineering for AI requests
- Response formatting and chunking for Telegram message limits
- Code extraction from AI responses for deployment
- Callback query handling for interactive deployment workflow

# External Dependencies

## AI Services
- **OpenAI API**: Primary AI service using GPT-5 model for text generation and Vision API for image analysis
- **Configuration**: Supports configurable model selection, token limits, and temperature settings

## Telegram Integration
- **Telegram Bot API**: Core bot functionality through `node-telegram-bot-api` package
- **File Processing**: Image download and processing capabilities for screenshot analysis

## Core Dependencies
- **axios**: HTTP client for external API requests and file downloads
- **dotenv**: Environment variable management for secure configuration
- **node-telegram-bot-api**: Telegram Bot API wrapper for Node.js
- **openai**: Official OpenAI API client library

## Infrastructure Requirements
- **Node.js**: Runtime environment (version 16 or higher)
- **Environment Variables**: Telegram Bot Token and OpenAI API Key required
- **Memory Storage**: In-memory session and rate limiting (suitable for single-instance deployment)

## Configuration Management
Environment-based configuration supporting:
- Development and production modes
- Configurable port settings (default: 8000)
- Image processing limits (max 20MB, multiple format support)
- AI model parameters and rate limiting settings