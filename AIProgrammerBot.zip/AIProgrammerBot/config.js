require('dotenv').config();

module.exports = {
    // Telegram Bot Token
    TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || '',
    
    // OpenAI API Key
    OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
    
    // OpenAI Configuration
    OPENAI_MODEL: 'gpt-5', // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
    OPENAI_MAX_TOKENS: 4000,
    OPENAI_TEMPERATURE: 0.7,
    
    // Image processing settings
    MAX_IMAGE_SIZE: 20 * 1024 * 1024, // 20MB
    SUPPORTED_IMAGE_FORMATS: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    
    // Rate limiting
    RATE_LIMIT_WINDOW: 60 * 1000, // 1 minute
    RATE_LIMIT_MAX_REQUESTS: 10,
    
    // Logging
    LOG_LEVEL: process.env.LOG_LEVEL || 'info',
    
    // Application settings
    PORT: process.env.PORT || 8000,
    NODE_ENV: process.env.NODE_ENV || 'development'
};
